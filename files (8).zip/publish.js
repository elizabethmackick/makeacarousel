const https = require('https');

function firebaseRequest(method, path, data) {
  return new Promise((resolve, reject) => {
    const body = data ? JSON.stringify(data) : null;
    const options = {
      hostname: 'makeacarousel-default-rtdb.firebaseio.com',
      path: path + '.json',
      method: method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (body) options.headers['Content-Length'] = Buffer.byteLength(body);

    const req = https.request(options, (res) => {
      let responseData = '';
      res.on('data', (chunk) => { responseData += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(responseData) });
        } catch (e) {
          resolve({ status: res.statusCode, data: responseData });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  // GET: check if slug exists
  if (event.httpMethod === 'GET') {
    const slug = event.queryStringParameters && event.queryStringParameters.slug;
    if (!slug) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing slug' }) };

    try {
      const result = await firebaseRequest('GET', '/decks/' + encodeURIComponent(slug));
      return {
        statusCode: 200, headers,
        body: JSON.stringify({ exists: result.data !== null, data: result.data })
      };
    } catch (e) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
    }
  }

  // POST: publish deck
  if (event.httpMethod === 'POST') {
    try {
      const { slug, data } = JSON.parse(event.body);
      if (!slug || !data) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing slug or data' }) };
      }

      // Check if slug already exists
      const existing = await firebaseRequest('GET', '/decks/' + encodeURIComponent(slug));
      if (existing.data !== null) {
        return { statusCode: 409, headers, body: JSON.stringify({ error: 'taken' }) };
      }

      // Write to Firebase
      const result = await firebaseRequest('PUT', '/decks/' + encodeURIComponent(slug), data);
      if (result.status >= 200 && result.status < 300) {
        return { statusCode: 200, headers, body: JSON.stringify({ ok: true, slug }) };
      } else {
        return { statusCode: result.status, headers, body: JSON.stringify({ error: 'Firebase write failed', detail: result.data }) };
      }
    } catch (e) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
    }
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
};

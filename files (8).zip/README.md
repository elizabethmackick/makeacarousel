# Carousel — Get Your Message Around

Swipeable slide deck builder for messaging apps.

## Deploy to Netlify via GitHub

### One-time setup (5 minutes):

1. **Create a GitHub repo**
   - Go to github.com → click **+** → **New repository**
   - Name it `carousel` (or anything)
   - Keep it Public or Private — either works
   - Click **Create repository**

2. **Upload these files**
   - On the repo page, click **"uploading an existing file"** link
   - Drag ALL files/folders from this project into the upload area:
     - `index.html`
     - `netlify.toml`
     - `netlify/functions/publish.js`
     - `netlify/functions/deck.js`
   - Click **Commit changes**

3. **Connect to Netlify**
   - Go to app.netlify.com → **Add new site** → **Import an existing project**
   - Choose **GitHub** → authorize → select your `carousel` repo
   - Leave all settings as default (no build command needed)
   - Click **Deploy site**

4. **Set your custom domain**
   - In Netlify: **Domain settings** → add `makeacarousel.com`
   - Point your GoDaddy DNS to Netlify (same as before)

### Future updates:
Just edit files on GitHub — Netlify auto-deploys on every push!

## How it works

- **Builder**: Single-page slide editor with themes, fonts, layouts
- **Share as Link**: Publishes deck to Firebase via Netlify Function → short custom URL
- **Viewer**: Reads deck from Firebase via Netlify Function → fullscreen swipeable view
- **Save Slides**: Exports slides as images for texting/sharing

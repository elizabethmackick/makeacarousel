const https = require('https');

function firebaseGet(path) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'makeacarousel-default-rtdb.firebaseio.com',
      path: path + '.json',
      method: 'GET'
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(data) }); }
        catch (e) { resolve({ status: res.statusCode, data: null }); }
      });
    });
    req.on('error', reject);
    req.end();
  });
}

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  const slug = event.queryStringParameters && event.queryStringParameters.slug;
  if (!slug) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing slug' }) };
  }

  try {
    const result = await firebaseGet('/decks/' + encodeURIComponent(slug));
    if (result.data === null) {
      return { statusCode: 404, headers, body: JSON.stringify({ error: 'Not found' }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify(result.data) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
